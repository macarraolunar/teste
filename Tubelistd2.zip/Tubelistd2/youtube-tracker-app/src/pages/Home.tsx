import React from 'react';

const Home: React.FC = () => {
    return (
        <div>
            <h1>Welcome to YouTube Tracker</h1>
            <p>Track your favorite YouTube videos, rate them, and manage your watch history!</p>
        </div>
    );
};

export default Home;