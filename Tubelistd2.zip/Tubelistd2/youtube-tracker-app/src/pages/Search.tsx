import React, { useState } from 'react';
import VideoList from '../components/VideoList';
import { fetchVideos } from '../api/youtube';

const Search: React.FC = () => {
    const [query, setQuery] = useState('');
    const [videos, setVideos] = useState([]);

    const handleSearch = async () => {
        const results = await fetchVideos(query);
        setVideos(results);
    };

    return (
        <div>
            <h1>Search for YouTube Videos</h1>
            <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search..."
            />
            <button onClick={handleSearch}>Search</button>
            <VideoList videos={videos} />
        </div>
    );
};

export default Search;