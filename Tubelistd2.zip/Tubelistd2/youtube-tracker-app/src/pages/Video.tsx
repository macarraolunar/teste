import React from 'react';
import VideoPage from '../components/VideoPage';

const Video: React.FC = () => {
    return <VideoPage />;
};

export default Video;