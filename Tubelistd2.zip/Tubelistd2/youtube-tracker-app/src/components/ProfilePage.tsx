import React from 'react';
import { useUserProfile } from '../api/user';
import FavoriteVideos from './FavoriteVideos';

const ProfilePage: React.FC = () => {
    const { user, loading, error } = useUserProfile();

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error loading profile</div>;

    return (
        <div className="profile-page">
            <img src={user.profilePicture} alt="Profile" className="profile-picture" />
            <h1>{user.name}</h1>
            <p>{user.bio}</p>
            <h2>Favorite Videos</h2>
            <FavoriteVideos favoriteVideos={user.favoriteVideos} />
        </div>
    );
};

export default ProfilePage;