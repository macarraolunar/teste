import React, { useState } from 'react';

const ProfileEditor: React.FC<{ onSave: (name: string, bio: string, profilePicture: File | null) => void }> = ({ onSave }) => {
    const [name, setName] = useState('');
    const [bio, setBio] = useState('');
    const [profilePicture, setProfilePicture] = useState<File | null>(null);

    const handleProfilePictureChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0] || null;
        setProfilePicture(file);
    };

    const handleSubmit = (event: React.FormEvent) => {
        event.preventDefault();
        onSave(name, bio, profilePicture);
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>
                    Profile Picture:
                    <input type="file" accept="image/*" onChange={handleProfilePictureChange} />
                </label>
            </div>
            <div>
                <label>
                    Name:
                    <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
                </label>
            </div>
            <div>
                <label>
                    Bio:
                    <textarea value={bio} onChange={(e) => setBio(e.target.value)} />
                </label>
            </div>
            <button type="submit">Save</button>
        </form>
    );
};

export default ProfileEditor;