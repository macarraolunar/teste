import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { fetchVideoDetails } from '../api/youtube';
import RatingStars from './RatingStars';

const VideoPage = () => {
    const { videoId } = useParams();
    const [video, setVideo] = useState(null);
    const [watched, setWatched] = useState(false);
    const [rating, setRating] = useState(0);

    useEffect(() => {
        const getVideoDetails = async () => {
            const videoData = await fetchVideoDetails(videoId);
            setVideo(videoData);
        };
        getVideoDetails();
    }, [videoId]);

    const handleWatch = () => {
        setWatched(true);
        // Logic to log the video as watched
    };

    const handleRating = (newRating) => {
        setRating(newRating);
        // Logic to save the rating
    };

    if (!video) return <div>Loading...</div>;

    return (
        <div>
            <h1>{video.title}</h1>
            <img src={video.thumbnail} alt={video.title} />
            <p>By: {video.author}</p>
            <p>Likes: {video.likes}</p>
            <p>Views: {video.views}</p>
            <button onClick={() => window.open(video.url, '_blank')}>Watch on YouTube</button>
            <button onClick={handleWatch} disabled={watched}>
                {watched ? 'Watched' : 'Mark as Watched'}
            </button>
            <RatingStars rating={rating} onRate={handleRating} />
        </div>
    );
};

export default VideoPage;