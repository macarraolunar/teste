import React from 'react';
import { Video } from '../types';

interface FavoriteVideosProps {
  favoriteVideos: Video[];
}

const FavoriteVideos: React.FC<FavoriteVideosProps> = ({ favoriteVideos }) => {
  return (
    <div className="favorite-videos">
      <h2>My Favorite Videos</h2>
      <div className="video-list">
        {favoriteVideos.map((video) => (
          <div key={video.id} className="video-card">
            <a href={video.url} target="_blank" rel="noopener noreferrer">
              <img src={video.thumbnail} alt={video.title} />
              <h3>{video.title}</h3>
              <p>By {video.author}</p>
              <p>{video.likes} Likes | {video.views} Views</p>
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FavoriteVideos;