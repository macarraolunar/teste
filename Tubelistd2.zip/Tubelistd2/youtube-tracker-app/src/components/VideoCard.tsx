import React from 'react';

interface VideoCardProps {
    thumbnail: string;
    title: string;
    author: string;
    likes: number;
    views: number;
    videoUrl: string;
}

const VideoCard: React.FC<VideoCardProps> = ({ thumbnail, title, author, likes, views, videoUrl }) => {
    return (
        <div className="video-card">
            <img src={thumbnail} alt={title} className="video-thumbnail" />
            <h3 className="video-title">{title}</h3>
            <p className="video-author">By: {author}</p>
            <p className="video-stats">{likes} Likes | {views} Views</p>
            <a href={videoUrl} target="_blank" rel="noopener noreferrer" className="video-link">
                Watch on YouTube
            </a>
        </div>
    );
};

export default VideoCard;