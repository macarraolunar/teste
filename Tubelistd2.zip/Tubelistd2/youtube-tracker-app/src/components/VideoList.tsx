import React from 'react';
import VideoCard from './VideoCard';
import { VideoData } from '../types';

interface VideoListProps {
  videos: VideoData[];
}

const VideoList: React.FC<VideoListProps> = ({ videos }) => {
  return (
    <div className="video-list">
      {videos.map(video => (
        <VideoCard key={video.id} video={video} />
      ))}
    </div>
  );
};

export default VideoList;