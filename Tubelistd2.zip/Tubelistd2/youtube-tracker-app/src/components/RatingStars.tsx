import React from 'react';

interface RatingStarsProps {
  rating: number;
  onRatingChange: (newRating: number) => void;
}

const RatingStars: React.FC<RatingStarsProps> = ({ rating, onRatingChange }) => {
  const stars = Array.from({ length: 10 }, (_, index) => index * 0.5 + 0.5);

  return (
    <div>
      {stars.map((star) => (
        <span
          key={star}
          style={{ cursor: 'pointer', color: star <= rating ? '#FFD700' : '#ccc' }}
          onClick={() => onRatingChange(star)}
        >
          ★
        </span>
      ))}
    </div>
  );
};

export default RatingStars;