export interface Video {
    id: string;
    title: string;
    author: string;
    thumbnail: string;
    likes: number;
    views: number;
    url: string;
}

export interface User {
    id: string;
    name: string;
    bio: string;
    profilePicture: string;
    favoriteVideos: string[]; // Array of video IDs
}

export interface WatchedVideo {
    videoId: string;
    rating: number | null; // Rating can be 0.5 to 5 or null if not rated
    watchedAt: Date;
}