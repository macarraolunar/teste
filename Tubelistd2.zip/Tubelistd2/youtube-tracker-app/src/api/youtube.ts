import axios from 'axios';

const YOUTUBE_API_KEY = 'YOUR_YOUTUBE_API_KEY';
const YOUTUBE_API_URL = 'https://www.googleapis.com/youtube/v3';

export const searchVideos = async (query: string) => {
    const response = await axios.get(`${YOUTUBE_API_URL}/search`, {
        params: {
            part: 'snippet',
            q: query,
            key: YOUTUBE_API_KEY,
            type: 'video',
            maxResults: 10,
        },
    });
    return response.data.items;
};

export const getVideoDetails = async (videoId: string) => {
    const response = await axios.get(`${YOUTUBE_API_URL}/videos`, {
        params: {
            part: 'snippet,statistics',
            id: videoId,
            key: YOUTUBE_API_KEY,
        },
    });
    return response.data.items[0];
};