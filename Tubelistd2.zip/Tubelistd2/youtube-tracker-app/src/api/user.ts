import { User, Video } from '../types';

const users: User[] = [];

export const createUser = (name: string, bio: string, profilePicture: string): User => {
    const newUser: User = {
        id: users.length + 1,
        name,
        bio,
        profilePicture,
        favoriteVideos: [],
        watchedVideos: []
    };
    users.push(newUser);
    return newUser;
};

export const updateUser = (id: number, name?: string, bio?: string, profilePicture?: string): User | undefined => {
    const user = users.find(user => user.id === id);
    if (user) {
        if (name) user.name = name;
        if (bio) user.bio = bio;
        if (profilePicture) user.profilePicture = profilePicture;
    }
    return user;
};

export const addFavoriteVideo = (userId: number, video: Video): boolean => {
    const user = users.find(user => user.id === userId);
    if (user && !user.favoriteVideos.includes(video)) {
        user.favoriteVideos.push(video);
        return true;
    }
    return false;
};

export const logWatchedVideo = (userId: number, video: Video): boolean => {
    const user = users.find(user => user.id === userId);
    if (user && !user.watchedVideos.includes(video)) {
        user.watchedVideos.push(video);
        return true;
    }
    return false;
};

export const getUserById = (id: number): User | undefined => {
    return users.find(user => user.id === id);
};