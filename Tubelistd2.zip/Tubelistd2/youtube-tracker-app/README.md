# YouTube Tracker App

YouTube Tracker is a web application that allows users to search for YouTube videos, log them as watched, rate them, and manage their profiles. Inspired by platforms like Letterboxd and Backloggd, this app focuses on enhancing the experience of watching and tracking YouTube content.

## Features

- **Video Search**: Search for YouTube videos and view their details including thumbnail, title, author, likes, and views.
- **Watch Logging**: Mark videos as watched, with the option to rate them from 0.5 to 5 stars or simply mark them without a rating.
- **User Profiles**: Create and manage user profiles with the ability to upload a profile picture, choose a display name, write a bio, and list favorite videos.
- **Favorite Videos**: Display a list of five favorite videos on the user profile page, complete with thumbnails linking to the respective video pages.
- **Video Pages**: Each video has its own page with detailed information and a button to redirect users to the video on YouTube.

## Project Structure

```
youtube-tracker-app
├── src
│   ├── components
│   │   ├── VideoCard.tsx
│   │   ├── VideoList.tsx
│   │   ├── VideoPage.tsx
│   │   ├── ProfilePage.tsx
│   │   ├── ProfileEditor.tsx
│   │   ├── FavoriteVideos.tsx
│   │   └── RatingStars.tsx
│   ├── pages
│   │   ├── Home.tsx
│   │   ├── Search.tsx
│   │   ├── Video.tsx
│   │   └── Profile.tsx
│   ├── api
│   │   ├── youtube.ts
│   │   └── user.ts
│   ├── types
│   │   └── index.ts
│   ├── utils
│   │   └── helpers.ts
│   ├── App.tsx
│   └── index.tsx
├── public
│   └── index.html
├── package.json
├── tsconfig.json
└── README.md
```

## Installation

1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the project directory:
   ```
   cd youtube-tracker-app
   ```
3. Install dependencies:
   ```
   npm install
   ```

## Usage

To start the application, run:
```
npm start
```
This will launch the app in your default web browser.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.